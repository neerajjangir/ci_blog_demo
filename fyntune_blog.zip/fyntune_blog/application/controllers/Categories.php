<?php

class Categories extends CI_Controller
{
  public function index(){
    $data['categories'] = $this->category_model->get_categories();
    $this->load->view('header');
    $this->load->view('category/all_categories' , $data);
    $this->load->view('footer');
	}

  public function create(){
    // check login
    if(!$this->session->userdata('logged_in')){
      redirect('users/login');
    }

    $this->form_validation->set_rules('name','Name','required');
    if($this->form_validation->run()===FALSE){

      $this->load->view('header');
      $this->load->view('category/create_category');
      $this->load->view('footer');

    } else {
			 $data  = array(
				'name' => $this->input->post('name') ,
			);
			$this->category_model->create_category($data);


       // set Message
       $this->session->set_flashdata('category_created' ,'Your category has benn created');
       redirect('categories');
    }

  }

  public function delete($id){
    // check login
    if(!$this->session->userdata('logged_in')){
      redirect('users/login');
    }

    $this->category_model->delete_category($id);
    // set Message
    $this->session->set_flashdata('category_deleted' ,'Your category has been deleted');
    redirect('categories');
  }
}
?>

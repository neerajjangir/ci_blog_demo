# Codeigniter-Blog-Application
This blog application is built on CodeIgniter Framework and Contains all basic features of blog application.

# Usage 
* step-1 : Create Database with name "ciblog"
* step-2 : Import Databse from "DB Backup/ciblog.sql"
* step-3 : copy all thses files in your localhost

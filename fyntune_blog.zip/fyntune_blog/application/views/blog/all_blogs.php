<!-- Bootstrap Core CSS -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">

<!-- Page Content -->
<div class="container">
	<div class="row">
	<h1>Blogs with category filter and pagination</h1>
	<br>
		<div class="col-md-3">
			<div class="list-group">
				<h3>Category</h3>
				<?php
				foreach ($category_data as $row) {
				?>
					<div class="list-group-item checkbox">
						<label><input type="checkbox" class="common_selector category" value="<?php echo $row['id']; ?>"> <?php echo ucwords($row['name']); ?></label>
					</div>
				<?php
				}
				?>
			</div>
		</div>

		<div class="col-md-9">
			<!-- Filter data -->
			<div class="row filter_data"></div>

			<!-- Pagination -->
			<div align="center" id="pagination_link"></div>
		</div>
	</div>

</div>

<style>
	#loading {
		text-align: center;
		background: url('<?php echo base_url(); ?>assets/loader.gif') no-repeat center;
		height: 150px;
	}
</style>

<script>
	$(document).ready(function() {
		filter_data(1);

		function filter_data(page) {
			$('.filter_data').html('<div id="loading" style="" ></div>');
			var action = 'fetch_data';
			var category = get_filter('category');
			$.ajax({
				url: "<?php echo base_url(); ?>posts/fetch_post/" + page,
				method: "POST",
				dataType: "JSON",
				data: {
					action: action,
					category: category,
				},
				success: function(data) {
					$('.filter_data').html(data.product_list);
					$('#pagination_link').html(data.pagination_link);
				}
			})
		}

		function get_filter(class_name) {
			var filter = [];
			$('.' + class_name + ':checked').each(function() {
				filter.push($(this).val());
			});
			return filter;
		}

		$(document).on('click', '.pagination li a', function(event) {
			event.preventDefault();
			var page = $(this).data('ci-pagination-page');
			filter_data(page);
		});

		$('.common_selector').click(function() {
			filter_data(1);
		});

	});
</script>

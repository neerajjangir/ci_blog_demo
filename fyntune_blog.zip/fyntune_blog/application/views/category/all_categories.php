<h2> All Categories</h2>
<?php foreach ($categories as $category) {  ?>
	<li class="list-group-item">
			<?php echo ucwords($category['name']); ?>
		<form class="cat-delete" action="categories/delete/<?php echo $category['id']; ?>" method="POST">
			<input type="submit" class="btn-link text-danger" value="[X]">
		</form>
	</li>
<?php } ?>

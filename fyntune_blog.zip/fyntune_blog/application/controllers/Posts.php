<?php

class Posts extends CI_controller
{

	//Home, post with filter
	public function index()
	{
		$data['category_data'] = $this->post_model->get_categories();
		$this->load->view('header');
		$this->load->view('blog/all_blogs', $data);
		$this->load->view('footer');
	}

	function fetch_post()
	{
		sleep(1);
		$category = $this->input->post('category');
		$config = array();
		$config['base_url'] = '#';
		$config['total_rows'] = $this->post_model->count_all($category);
		$config['per_page'] = 3;
		$config['uri_segment'] = 3;
		$config['use_page_numbers'] = TRUE;
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['first_tag_open'] = '<li>';
		$config['first_tag_close'] = '</li>';
		$config['last_tag_open'] = '<li>';
		$config['last_tag_close'] = '</li>';
		$config['next_link'] = '&gt;';
		$config['next_tag_open'] = '<li>';
		$config['next_tag_close'] = '</li>';
		$config['prev_link'] = '&lt;';
		$config['prev_tag_open'] = '<li>';
		$config['prev_tag_close'] = '</li>';
		$config['cur_tag_open'] = "<li class='active'><a href='#'>";
		$config['cur_tag_close'] = '</a></li>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		$config['num_links'] = 3;
		$this->pagination->initialize($config);
		$page = $this->uri->segment(3);
		$start = ($page - 1) * $config['per_page'];
		$output = array(
			'pagination_link'  => $this->pagination->create_links(),
			'product_list'   => $this->post_model->fetch_postdata($config["per_page"], $start, $category)
		);
		echo json_encode($output);
	}

	//Single post
	public function view($slug = NULL)
	{
		$data['post'] = $this->post_model->get_posts($slug);

		if (empty($data['post'])) {
			show_404();
		}

		$data['title'] = $data['post']['title'];

		$this->load->view('header');
		$this->load->view('blog/single_blog', $data);
		$this->load->view('footer');
	}

	//Create new post
	public function create()
	{
		// check login
		if (!$this->session->userdata('logged_in')) {
			redirect('users/login');
		}

		$data['title'] = "Create Post";
		$data['categories'] = $this->post_model->get_categories();

		// validtion Rules
		$this->form_validation->set_rules('title', 'Title', 'required');
		$this->form_validation->set_rules('content', 'Content', 'required');

		// check wether form is submitted or Not
		if ($this->form_validation->run() === FALSE) {
			$this->load->view('header');
			$this->load->view('blog/create_blog', $data);
			$this->load->view('footer');
		} else {
			// Upload Image
			$config['upload_path'] = './uploads/posts';
			$config['allowed_types'] = 'gif|jpg|png';

			$this->load->library('upload', $config);

			if (!$this->upload->do_upload()) {
				$errors = array('error' => $this->upload->display_errors());
				$post_image = 'noimage.jpg';
			} else {
				$data = array('upload_data' => $this->upload->data());
				$post_image = $_FILES['userfile']['name'];
			}

			$slug = url_title($this->input->post('title'));

			$data = array(
				'title' => $this->input->post('title'),
				'slug' => $slug,
				'content' => $this->input->post('content'),
				'category_id' => $this->input->post('category_id'),
				'post_image' => $post_image
			);

			$this->post_model->create_post($data);

			//Set message
			$this->session->set_flashdata('post_created', 'Your post has been created');

			redirect('posts');
		}
	}

	//Delete post
	public function delete($id)
	{
		// check login
		if (!$this->session->userdata('logged_in')) {
			redirect('users/login');
		}

		$this->post_model->delete_post($id);
		// set Message
		$this->session->set_flashdata('post_deleted', 'Your post has been deleted');
		redirect('posts');
	}

	//Edit post
	public function edit($slug)
	{
		// Check login
		if (!$this->session->userdata('logged_in')) {
			redirect('users/login');
		}

		$data['post'] = $this->post_model->get_posts($slug);

		// Check user
		if (empty($this->session->userdata('user_id'))) {
			redirect('posts');
		}

		$data['categories'] = $this->post_model->get_categories();

		if (empty($data['post'])) {
			show_404();
		}

		$this->load->view('header');
		$this->load->view('blog/edit_blog', $data);
		$this->load->view('footer');
	}

	//Update post
	public function update()
	{
		// check login
		if (!$this->session->userdata('logged_in')) {
			redirect('users/login');
		}

		$slug = url_title($this->input->post('title'));

		$data = array(
			'id' => $this->input->post('id'),
			'title' => $this->input->post('title'),
			'slug' => $slug,
			'content' => $this->input->post('content'),
			'category_id' => $this->input->post('category_id')
		);
		// print_r($data);exit;

		$this->post_model->update($data);
		// set Message
		$this->session->set_flashdata('post_updated', 'Your post has been updated');
		redirect('posts');
	}
}

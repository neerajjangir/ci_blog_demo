<?php

class Post_model extends CI_Model
{
	public function __construct()
	{
		$this->load->database();
	}

	//post with filter
	function fetch_filter_type()
	{
		$this->db->distinct();
		$this->db->select('category_id');
		$this->db->from('posts');
		return $this->db->get();
	}

	function make_query($category)
	{
		$query = "
  SELECT * FROM posts
  ";

		if (isset($category)) {
			$category_filter = implode("','", $category);
			$query .= "
    WHERE category_id IN ('" . $category_filter . "')
   ";
		}
		return $query;
	}

	function count_all($category)
	{
		$query = $this->make_query($category);
		$data = $this->db->query($query);
		return $data->num_rows();
	}

	function fetch_postdata($limit, $start, $category)
	{
		$query = $this->make_query($category);

		$query .= ' LIMIT ' . $start . ', ' . $limit;

		$data = $this->db->query($query);

		$output = '';
		if ($data->num_rows() > 0) {
			foreach ($data->result_array() as $row) {
				$this->db->select('name');
				$name = $this->db->get_where('categories', array('id' => $row['category_id']));
				$output .= '
    <div class="col-sm-4 col-lg-4 col-md-4">
     <div style="border:1px solid #ccc; padding:10px; margin-bottom:10px;">
      <img src="' . base_url() . 'uploads/posts/' . $row['post_image'] . '" alt="" class="img-responsive" >
      <h4 align="center"><strong><a href=' . base_url('posts/') . $row['slug'] . '>' . ucwords($row['title']) . '</a></strong></h4>
      <h4 style="text-align:center;" class="text-danger" >' . ucwords($name->row('name')) . '</h4>
     </div>
    </div>
    ';
			}
		} else {
			$output = '<h3>No Post Found</h3>';
		}
		return $output;
	}

//Single post
	public function get_posts($slug = FALSE, $limit = FALSE, $offset = FALSE)
	{
		if ($limit) {
			$this->db->limit($limit, $offset);
		}
		if ($slug === FALSE) {
			$this->db->order_by('posts.id', 'DESC');
			$this->db->join('categories', 'categories.id = posts.category_id');
			$query = $this->db->get('posts');
			return $query->result_array();
		}

		$query = $this->db->get_where('posts', array('slug' => $slug));
		return $query->row_array();
	}

	//Create nre post
	public function create_post($data)
	{
		return $this->db->insert('posts', $data);
	}

	//Delete post
	public function delete_post($id)
	{
		$image_file_name = $this->db->select('post_image')->get_where('posts', array('id' => $id))->row()->post_image;
		$cwd = getcwd(); // save the current working directory
		$image_file_path = $cwd . "\\assets\\images\\posts\\";
		chdir($image_file_path);
		unlink($image_file_name);
		chdir($cwd); // Restore the previous working directory
		$this->db->where('id', $id);
		$this->db->delete('posts');
		return true;
	}

	//Update post
	public function update($data)
	{
		$this->db->where('id', $data['id']);
		$this->db->update('posts', $data);
	}

	//Get all category
	public function get_categories()
	{
		$this->db->order_by('name');
		$query = $this->db->get('categories');
		return $query->result_array();
	}
}

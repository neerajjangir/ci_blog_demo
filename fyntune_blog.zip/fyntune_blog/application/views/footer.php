     </div>
     <script>
        CKEDITOR.replace('my_editor');
     </script>
  </body>
</html>
